from flask import Flask, render_template, request
from your_module import BankingSystem

app = Flask(__name__)
bank = BankingSystem()
